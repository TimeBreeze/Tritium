#!/system/bin/sh

lock() {
    for file in $1; do
        if [ -f "$file" ]; then
            chown "root:root" "$file"
            chmod 0000 "$file"
        fi
    done
}

# Disable MediaTek PowerHal.
lock "/proc/*perfmgr*/*_ioctl"
