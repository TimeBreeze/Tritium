#!/sbin/sh
SKIPUNZIP=1

ui_print "= CuJankDetector Module ="
ui_print ""
ui_print "** WARNING: INJECTING INTO SYSTEM PROCESS"
ui_print "** MAY CAUSE SYSTEM CRASHES!!!"
ui_print ""
ui_print "- Installing..."

ui_print "- Check environment."
if [ "$(getprop ro.build.version.sdk)" -lt 31 || "$(getprop ro.product.cpu.abi)" != "arm64-v8a" ]; then
	abort "- Your device does not meet the requirement, Abort."
fi

if [ -n "$KSU_VER" ]; then
	ui_print "- Detected KernelSU ${KSU_VER}."
	echo "allow surfaceflinger * * *" > "${MODPATH}/sepolicy.rule"
fi

ui_print "- Extracting module files."
unzip -o "$ZIPFILE" -x "META-INF/*" -d "$MODPATH" >/dev/null 2>&1

ui_print "- Set permissions."
chmod -R 0777 "$MODPATH"
chcon -t "surfaceflinger" "${MODPATH}/system/bin/injector"
chcon -t "surfaceflinger" "${MODPATH}/system/lib64/libCuJankDetector.so"

ui_print "- Installation finished."
