#!/system/bin/sh
BASE_DIR=$(dirname "$0")

true > /dev/jank_message_v2
if [ ! -f "/dev/jank_message_v2" ]; then
	exit 0
fi
chmod 0666 /dev/jank_message_v2

while [ ! -n "$(pidof surfaceflinger)" ]; do
	sleep 1
done

if [ -n "$(which magiskpolicy)" ]; then
	magiskpolicy --live "allow surfaceflinger * * *" 2>/dev/null
fi

sleep 5

"${BASE_DIR}/bin/injector" -p "$(pidof surfaceflinger)" -l "/system/lib64/libCuJankDetector.so" > "${BASE_DIR}/inject.log" 2>&1

sleep 30
if [ -f "${BASE_DIR}/.system_crashed" ]; then
	rm -f "${BASE_DIR}/.system_crashed"
fi
