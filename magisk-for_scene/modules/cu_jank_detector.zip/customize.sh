#!/system/bin/sh

ui_print "- CuJankDetector Magisk Module"
ui_print ""
ui_print "** WARNING: INJECTING INTO SYSTEM PROCESS"
ui_print "** MAY CAUSE SYSTEM CRASHES!!!"
ui_print ""

ui_print "- Check Environment."
if [ $(getprop ro.build.version.sdk) -lt 31 || $(getprop ro.product.cpu.abi) != "arm64-v8a" ] ; then
	abort "- Your device does not meet the requirement, Abort."
fi

ui_print "- Extract Files."
unzip -o "${ZIPFILE}" -x 'META-INF/*' -d ${MODPATH} >&2

ui_print "- Set Permission."
chmod -R 7777 ${MODPATH}

ui_print "- Install Finished."
