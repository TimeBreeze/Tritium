#!/system/bin/sh
BASE_DIR=$(dirname $0)

if [ $(getprop ro.build.version.sdk) -lt 31 || $(getprop ro.product.cpu.abi) != "arm64-v8a" ] ; then
	exit 0
fi

echo "" > /dev/jank.message
chmod 0666 /dev/jank.message
if [ ! -e /dev/jank.message ]; then
	exit 0
fi

while [ ! -n "$(pgrep -f surfaceflinger)" ] ; do
	sleep 1;
done

magiskpolicy --live "allow surfaceflinger * * *"
sleep 5
/system/bin/injector -p $(pgrep -f surfaceflinger) -so /system/lib64/libCuJankDetector.so > ${BASE_DIR}/inject.log 2>&1

sleep 30
if [ -e ${BASE_DIR}/.system_crashed ] ; then
	rm -f ${BASE_DIR}/.system_crashed
fi
